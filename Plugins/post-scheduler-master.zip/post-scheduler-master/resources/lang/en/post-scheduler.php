<?php

return [
    'name' => 'Post Scheduler',
];
