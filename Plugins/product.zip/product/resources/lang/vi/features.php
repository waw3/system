<?php

return [
    'name'   => 'Features',
    'create' => 'New features',
    'edit'   => 'Edit features',
    'form' =>[
    	'features' => 'Tiện ích',
    	'button_add_image' => 'Thêm Hình Ảnh',
    	'button_add_color' => 'Thêm Màu',
        'button_add_size' => 'Thêm kích thước',
    	'images' => 'Hình Ảnh',
    	'colors' => 'Màu',
        'sizes' => 'Kích Cỡ',
    ],
];
