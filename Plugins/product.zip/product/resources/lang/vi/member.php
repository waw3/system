<?php

return [
    'dob'             => 'Ngày Đăng',
    'draft_posts'     => 'Sản phẩm nháp',
    'pending_posts'   => 'Sản phẩm chờ xét duyệt',
    'published_posts' => 'Sản phẩm đã đăng',
    'products'           => 'Sản phẩm',
    'write_product'      => 'Đăng sản phẩm mới',
];
