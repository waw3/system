<?php

return [
    'menu_name' => 'Bán Hàng',
    'product_page' => 'Trang Sản Phẩm',
];