<?php

return [
    'create' => 'Tạo Danh Mục Sản Phẩm',
    'edit' => 'Sửa Danh Mục Sản Phẩm',
    'menu' => 'Danh Mục Sản Phẩm',
    'edit_this_procategory' => 'Chỉnh sửa danh mục sản phẩm này',
    'menu_name' => 'Danh mục sản phẩm',
    'none' => 'None',
];
