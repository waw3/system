<?php

return [
    'name'   => 'Payments',
    'create' => 'New payment',
    'edit'   => 'Edit payment',
    'form' 	=> [
    	'paymentstatus' => 'Payment Status'
    ]
];
