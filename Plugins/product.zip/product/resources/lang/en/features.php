<?php

return [
    'name'   => 'Features',
    'create' => 'New features',
    'edit'   => 'Edit features',
    'form' =>[
    	'features' => 'Tiện ích',
    	'button_add_image' => 'Add image',
    	'button_add_color' => 'Add color',
        'button_add_size' => 'Add size',
    	'images' => 'Images',
    	'colors' => 'Colors',
        'sizes' => 'Sizes',
    ],
];
