<?php

return [
    'menu_name' => 'Product',
    'product_page' => 'Product Page',
];