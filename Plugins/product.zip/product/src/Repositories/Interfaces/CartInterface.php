<?php

namespace Botble\Product\Repositories\Interfaces;

use Botble\Support\Repositories\Interfaces\RepositoryInterface;
use Illuminate\Support\Collection;
use Eloquent;

interface CartInterface extends RepositoryInterface
{
}
