<?php

namespace Botble\Product\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Product\Repositories\Interfaces\OrderstatusInterface;

class OrderstatusCacheDecorator extends CacheAbstractDecorator implements OrderstatusInterface
{

}
