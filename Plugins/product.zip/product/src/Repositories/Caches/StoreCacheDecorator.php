<?php

namespace Botble\Product\Repositories\Caches;

use Botble\Support\Repositories\Caches\CacheAbstractDecorator;
use Botble\Product\Repositories\Interfaces\StoreInterface;

class StoreCacheDecorator extends CacheAbstractDecorator implements StoreInterface
{

}
