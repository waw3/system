<?php

namespace Botble\GitCommitChecker\Tests;

use PHPUnit\Framework\TestCase;

class GitCommitCheckerTest extends TestCase
{
    public function testExample()
    {
        $this->assertTrue(true);
    }
}
