**EXPERIMENTAL**: Anything regarding Guide generation, in this folder or elsewhere, is to be considered experimental
and prone to be changed or removed without notice or consideration for BC.

This is a follow-up to an earlier POC and can, at best, seen as an incubator project.
