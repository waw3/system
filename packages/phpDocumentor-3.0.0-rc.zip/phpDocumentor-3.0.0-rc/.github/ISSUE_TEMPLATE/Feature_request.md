---
name: Feature request 🚀
about: I have a suggestion (and may want to implement it 🙂)!
---

# Feature request

<!-- Please provide a clear description of what problem you are trying to solve and how would you want it to be solved. -->
