<?php

namespace Marios;

const OVEN_TEMPERATURE = 9001;
define('HIGHER_OVEN_TEMPERATURE', 9002);
