<?php declare(strict_types=1);

namespace Marios\Pizza;

/**
 * Did you see this explanation?
 *
 * I have tried to write down something sensible; just as I had planned with this example.
 *
 * > Unfortunately, life did not pan out as I had expected. I will have to do with
 * > making examples that don't make sense?
 *
 * Just like this one, though I managed to sneak a blockquote in.
 */
final class Base
{
    public function __construct(?Sauce $sauce)
    {
    }
}
