<?php

namespace Marios;

function heatOven()
{
}

function coolOven(int $degrees): bool
{
    return true;
}

function populateTemperature(int &$temperature): void
{
}
